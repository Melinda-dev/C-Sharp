﻿
namespace HolmesglenStudentManagementSystem.DataAccessLayer
{
    public class HolmesglenDB
    {
        // student todo -
        // correctly define the connection string for the target database
        public static string ConnectionString = @"Data Source=C:\Users\liu_s\OneDrive\Documents\Holmesglen Assessment\C#\Assessment 2\AT2Project\HolmesglenStudentManagementSystem.db";
    }
}
