﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity_Framework.Models
{
    public class Enrollment
    {
        public string EnrollmentID { get; set; }
        public string StudentID { get; set; }
        public string SubjectID { get; set; }
    }
}
